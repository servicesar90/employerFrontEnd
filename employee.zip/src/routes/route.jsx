import React from 'react';
import { Route, Routes, Outlet } from 'react-router-dom';
import Home from '../views/home';
import Header from '../components/ui/header'
import Footer from '../components/ui/footer'
import EmployerHome from '../views/employerHome';
import ProfileUpdate from '../components/modals/profileUpdate';
import Jobs from '../components/pages/jobs';
import PostJob from '../components/modals/createJobModal';
import CandidateManagementPage from '../components/pages/jobDetail';
import SearchCandidatesForm from '../components/modals/searchCandidateModal';
import UnlockedCandidates from '../components/pages/unlockCandidate';
import ApplicationsReportCard from '../components/modals/ReportCard';
import DownloadApplicationsCard from '../components/modals/reportDownloadModal';


function Layout() {
    return (
      <>
        <Header />
        <Outlet />
        <Footer />
      </>
    )
  }
  


export default function Routess() {
    return (
        <Routes>
            <Route path='/' element={<Layout />}>
                <Route index element={<Home />} />
                <Route path='/employerHome' element={<EmployerHome />}>
                    <Route index element={<Jobs />} />
                    <Route path='Jobs' element={<Jobs />} />
                    <Route path="jobsDetail/:id" element={<CandidateManagementPage />} />
                    <Route path='SearchCandidates' element={<SearchCandidatesForm />} />
                    <Route path='UnlockedCandidates' element={<UnlockedCandidates />} />
                    <Route path='Reports' element={<ApplicationsReportCard />} />
                    <Route path="downloadReport" element={<DownloadApplicationsCard />} />
                </Route>

                <Route path='/jobsModal' element={<PostJob />} />
                <Route path='/profile' element={<ProfileUpdate />} />
                
            </Route>
        </Routes>
    )
}
