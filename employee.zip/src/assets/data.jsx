export const employer={
    name: "Abhishek jha",
    email: "ajha@gmail.com",
    mobileNumber: "9475638393",
    credits: 0,
    jobs:[{
        id: 1,
        age: "18-25",
    candidateType: "all candidate",
    companyName: "Byjus",
    contactPreference: "other",
    distance: "",
    education: "ITI",
    english: "Good English",
    experience: "Experienced Only",
    experienceLevel: "1 year",
    gender: "Female",
    incentive: "2000",
    jobDescription: "this is an ITI job",
    jobTitle: "ITI Accountant",
    jobType: "full-time",
    joiningFeeAmount: "100",
    joiningFeeAmountTime: "before-interview",
    joiningFeesAmountReason: "registration-fees",
    joiningFeesAmountReasonDetail: "100",
    joiningfee: "true",
    languages: "English",
    location: "Noida Uttar pradesh",
    maximumSalary: "30000",
    minimumSalary: "20000",
    nightShift: false,
    notificationPreference: "yes",
    otherRecruiterEmail: "aj257453@gmail.com",
    otherRecruiterName: "Aditya jain",
    otherRecruiterNumber: "9540441958",
    payType: "fixed-incentive",
    perks:  ['Weekly Payout', 'Petrol Allowance', 'Internet Allowance'],
    skills: "",
    specialization: "",
    walkIn: "yes",
    walkInAddress: "Noida uttar pradesh ",
    walkInEndDate: "2025-04-30",
    walkInEndTime: "18:00",
    walkInInstructions: "Bring ID cards",
    walkInStartDate: "2025-04-18",
    walkInStartTime: "10:00",
    workLocationType: "work-from-office",
    jobActivity: {
            status:"Active",
            postedOn:"12 Apr 2025",
            recruiter:"Shilpi Sinha",
            appliedCount:13,
            pendingCount:13,
            dbMatches:15711
    },
    candidatesData:[
        {
        name: "Aditya jain",
        gender: "male",
        age: "27",
        yearExperience: "2",
        currentSalary: "32000",
        location: "Gulab vatika, loni",
        experience: {title: "Content Manager", joinDate:"oct 2024", endDate:"present",jobRole:"Creating Educational Content", industry: "Educational"},
        education: {degree: "M.sc", subject: "IT", university: "Amity university"},
        skills: ["Content Writing, Presentations, Subject matter Expert"],
        status:"",
        match: true,
        }
    ]
    }],
    documents:{},
    databases: {}
}

export const candidates=[{
    
    name: "Shalini Shukla",
    experience: "3 yrs 3 mos",
    salary: "2.2 Lakhs",
    location: "Indirapuram, Ghaziabad",
    currentJob: "Non IT Recruiter at Esjobs",
    previousJob: "HR Recruiter at Tech Mahindra Ltd",
    education: "LLB, Law, Chaudhary Charan Singh University",
    prefLocations: ["Jaipur Region", "Delhi-NCR", "Chandigarh Region"],
    skills: ["MS Word", "MS Excel", "FMCG/Retail Sales", "Meeting scheduling", "Convincing skills"],
    languages: "English (Good)",
    image: null // or URL string if available
  
}
]



const candidateSearch={
    activeIn: "6",
education: ['10th pass', 'ITI'],
keywords: "gfgs",
location: "ggdffd",
maxExperience: 1,
maxSalary: 2,
minExperience: 1,
minSalary: 1,
type: "experienced"
}

