import './App.css'
import { BrowserRouter as Router } from 'react-router-dom'

import Routess from './routes/route'



function App() {


  return (
    <>
      <Router>
        <Routess />
      </Router>


    </>
  )
}

export default App
